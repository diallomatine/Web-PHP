#Author: Diallo Abdoul Matine et Diallo Aissatou Lamarana
-------
#GROUPE 2
---------

#Presentation
Ce projet consiste à la simulation de distribution de courriers dans les villes

#OBJECTIF
----------
Pratiquer une bonne conception de programmation en appliquant les principes
du SOLID, DRY, KISS

#DOCUMENTATION
---------------
pour obtenir la documentation du projet, il suffit depuis un terminal se placer
dans le dossier racine du projet et taper la commande mvn javadoc:javadoc

#COMPILATION DE CODE SOURCE
---------------------------
Pour compiler le code source, il suffit
 dans le dosser racine du projet et taper la commande mvn package

#EXÉCUTION DU PROGRAMME
-----------------------
se placer à la racine du projet et taper la commande:
java -jar target/TP2-COURRIER-1.0-SNAPSHOT.jar


#PARTIE NON REALISEE
--------------------
Les chaines Naifs n'ont pas été realisés
