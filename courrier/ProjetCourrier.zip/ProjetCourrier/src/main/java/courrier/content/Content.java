package courrier.content;

public interface Content<T> {
	public  T getContent();
}
